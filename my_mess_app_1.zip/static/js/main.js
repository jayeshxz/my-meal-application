// MY MESS — shared front-end behaviour.
// Kept deliberately small: the server (app.py) owns all real logic
// (auth, amounts, dates). This file only makes the forms feel alive.

document.addEventListener("DOMContentLoaded", () => {
  wireFilePreview("avatar", "avatarPreview");
  wireFilePreview("proof", "proofPreview");
  wirePlanPicker();
  wireTabLinks();
});

function wireFilePreview(inputId, previewId) {
  const input = document.getElementById(inputId);
  const preview = document.getElementById(previewId);
  if (!input || !preview) return;

  input.addEventListener("change", () => {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      preview.innerHTML = `<img src="${e.target.result}" alt="preview">`;
    };
    reader.readAsDataURL(file);
  });
}

function wirePlanPicker() {
  const planOptions = document.querySelectorAll(".plan-option[data-plan]");
  const timeOptions = document.querySelectorAll(".plan-option[data-time]");
  const oneTimeSection = document.getElementById("oneTimeSection");
  const amountEl = document.getElementById("livePreviewAmount");
  const monthlyCharge = amountEl ? parseFloat(amountEl.dataset.monthly || "0") : 0;

  function updateAmountPreview() {
    if (!amountEl) return;
    const selectedPlan = document.querySelector(".plan-option[data-plan].selected");
    const plan = selectedPlan ? selectedPlan.dataset.plan : "both";
    const amount = plan === "both" ? monthlyCharge : Math.round(monthlyCharge * 0.6);
    amountEl.textContent = "₹" + amount.toLocaleString("en-IN");
  }

  planOptions.forEach((opt) => {
    opt.addEventListener("click", () => {
      planOptions.forEach((o) => o.classList.remove("selected"));
      opt.classList.add("selected");
      const input = opt.querySelector("input");
      if (input) input.checked = true;

      if (oneTimeSection) {
        oneTimeSection.classList.toggle("hidden", opt.dataset.plan !== "one");
      }
      updateAmountPreview();
    });
  });

  timeOptions.forEach((opt) => {
    opt.addEventListener("click", () => {
      timeOptions.forEach((o) => o.classList.remove("selected"));
      opt.classList.add("selected");
      const input = opt.querySelector("input");
      if (input) input.checked = true;
    });
  });

  updateAmountPreview();
}

function wireTabLinks() {
  // Tabs are plain links with ?tab=xxx (server renders the active tab),
  // this just adds instant visual feedback before the page reload.
  document.querySelectorAll(".tabbtn").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tabbtn").forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
    });
  });
}

function copyText(text) {
  navigator.clipboard.writeText(text);
}
